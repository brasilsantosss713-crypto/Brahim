# SaharaBot

A working Discord.js bot skeleton implementing a solid slice of SaharaBot's
feature set: moderation, admin, games, economy, leveling, and utilities. It's
built to be extended — the full 350+ command list is a big project, so this
gives you a real, running foundation with ~50 fully working commands you can
build on, organized exactly like the rest would be.

## What's included

- **Moderation**: ban, unban, kick, timeout, untimeout, mute, unmute, warn,
  warnings, clearwarnings, purge, delete, lock, unlock, slowmode, report,
  modlogs, automod
- **Admin**: role, nick, promote, demote, announce, embed, reactionroles,
  welcome, goodbye, backup, restore, settings, permissions, serverstats,
  channelcreate, channeldelete
- **Games**: coinflip, diceroll, rps, 8ball, trivia, tictactoe (interactive
  buttons, 2-player), guessnumber
- **Economy**: balance, daily, work, pay, bank, richest, gamble (JSON-file
  persisted)
- **Leveling**: rank, leaderboard, plus passive XP gain from chatting
- **Utilities**: ping, userinfo, serverinfo, avatar, calculator, remindme,
  uptime, invite
- **AI** (via the Anthropic API): ask, chat (with per-channel memory),
  resetchat, summarize, aitranslate, brainstorm, explain, rewrite, codehelp
- **Music** (via `@discordjs/voice` + `play-dl`): play, pause, resume, skip,
  stop, queue, nowplaying, loop, shuffle, remove, volume, leavevc — full
  per-server queue with auto-leave after 5 minutes idle

## Setup

1. **Install Node.js 18+** if you don't have it.
2. **Create a Discord application** at https://discord.com/developers/applications
   - Go to the "Bot" tab, click "Add Bot"
   - Under "Privileged Gateway Intents", enable **Server Members Intent** and
     **Message Content Intent**
   - Under "Bot Permissions" (or when generating your invite link), make sure
     **Manage Roles**, **Manage Channels**, and **Add Reactions** are checked
     — the new mute, promote/demote, and reactionroles commands need them
   - Copy the bot token
   - On the "OAuth2 > General" page, copy your Application (Client) ID
3. **Install dependencies**:
   ```bash
   cd saharabot
   npm install
   ```
4. **Configure environment variables**:
   ```bash
   cp .env.example .env
   ```
   Then edit `.env` and fill in `DISCORD_TOKEN` and `CLIENT_ID`. If you want
   instant command updates while developing, also set `GUILD_ID` to your test
   server's ID (right-click the server icon in Discord with Developer Mode
   enabled → Copy Server ID).
5. **For AI commands**, get an API key from https://console.anthropic.com/
   and add it to `.env` as `ANTHROPIC_API_KEY`. Without it, the AI commands
   will reply with an error but the rest of the bot works fine.
6. **For music commands**, you also need `ffmpeg` available on your system
   (the `ffmpeg-static` dependency handles this automatically on most
   platforms — no separate install needed). Music requires the bot to have
   **Connect** and **Speak** permissions in your voice channels.
7. **Deploy the slash commands**:
   ```bash
   npm run deploy
   ```
8. **Configure your server's settings** once the bot is running — run
   `/settings modlog-channel`, `/welcome`, `/goodbye`, and
   `/settings hierarchy-add` (in the order you want members promoted through)
   to wire up the new features. `/mute` will auto-create a Muted role and
   lock it out of every channel the first time it's used.
9. **Invite the bot to your server** using the OAuth2 URL generator on the
   Discord Developer Portal (scopes: `bot`, `applications.commands`; permissions
   as needed — Administrator is simplest while testing).
10. **Start the bot**:
    ```bash
    npm start
    ```

## Project structure

```
saharabot/
├── index.js              # Bot entry point — logs in, loads commands, handles events
├── deploy-commands.js     # Registers slash commands with Discord
├── package.json
├── .env.example
└── src/
    ├── commands/
    │   ├── moderation.js
    │   ├── admin.js
    │   ├── games.js
    │   ├── economy.js
    │   ├── leveling.js
    │   ├── utility.js
    │   ├── ai.js          # Anthropic API-backed commands
    │   └── music.js       # Slash commands for the music queue
    ├── music/
    │   └── queue.js       # Per-guild voice connection + queue logic
    └── data/
        ├── store.js       # Simple JSON-file data persistence
        └── storage/       # Auto-created — economy.json, levels.json, warnings.json
```

## Extending it

To add a new command:

1. Open (or create) a file in `src/commands/`.
2. Add a new object to the exported array with a `data` (SlashCommandBuilder)
   and an `execute(interaction)` function.
3. Run `npm run deploy` again to register it.

That's the same pattern used throughout — copy an existing command in the
relevant category as a template.

## Notes on scale

- The JSON file storage in `src/data/store.js` is fine for small/medium
  servers. For a large multi-server bot, swap it for a real database
  (PostgreSQL, MongoDB, SQLite via an ORM like Prisma).
- **Music**: `play-dl` scrapes YouTube directly with no official API key
  needed, but YouTube can occasionally change things in ways that break
  scraping libraries — if playback stops working, check for a `play-dl`
  update first. For heavier use (many servers, more reliability), consider
  migrating to a Lavalink-based library like `shoukaku` or `erela.js`
  instead, which offload audio processing to a separate audio node.
- **Moderation & Admin extras**: `/mute`/`/unmute` use a real "Muted" role
  (auto-created and locked out of every channel on first use) rather than
  Discord's native timeout, so mutes can last indefinitely. `/backup` and
  `/restore` only ever *add* roles/channels that are missing by name — they
  never delete or modify anything, so restoring is safe to run repeatedly.
  `/reactionroles` supports up to 3 emoji→role pairs per message; run it
  again for additional messages if you need more options.
- **AI**: the `/chat` command keeps a short rolling conversation history
  per-channel in memory (lost on restart). `/ask` and the rest are
  stateless, one-off requests. Uses `claude-sonnet-4-6` — change the
  `MODEL` constant at the top of `src/commands/ai.js` if you want a
  different model. API usage is billed per the Anthropic API's standard
  token pricing.
