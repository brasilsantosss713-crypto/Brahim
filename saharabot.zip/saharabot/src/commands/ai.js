const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

let Anthropic;
try {
  Anthropic = require('@anthropic-ai/sdk');
} catch {
  Anthropic = null;
}

const MODEL = 'claude-sonnet-4-6';
const MAX_DISCORD_LENGTH = 1900; // leave headroom under Discord's 2000 char limit

function getClient() {
  if (!Anthropic) {
    throw new Error("The '@anthropic-ai/sdk' package isn't installed. Run `npm install @anthropic-ai/sdk`.");
  }
  if (!process.env.ANTHROPIC_API_KEY) {
    throw new Error('ANTHROPIC_API_KEY is not set in your .env file.');
  }
  return new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
}

function chunkText(text, size = MAX_DISCORD_LENGTH) {
  const chunks = [];
  let remaining = text;
  while (remaining.length > size) {
    let splitAt = remaining.lastIndexOf('\n', size);
    if (splitAt <= 0) splitAt = size;
    chunks.push(remaining.slice(0, splitAt));
    remaining = remaining.slice(splitAt);
  }
  chunks.push(remaining);
  return chunks;
}

async function replyWithText(interaction, text) {
  const chunks = chunkText(text);
  await interaction.editReply(chunks[0]);
  for (let i = 1; i < chunks.length; i++) {
    await interaction.followUp(chunks[i]);
  }
}

// Simple in-memory per-channel conversation history for /chat.
// Resets on bot restart — swap for persistent storage if you need continuity.
const conversations = new Map();
const MAX_HISTORY_MESSAGES = 20;

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('ask')
      .setDescription('Ask the AI a one-off question')
      .addStringOption(o => o.setName('question').setDescription('Your question').setRequired(true)),
    async execute(interaction) {
      await interaction.deferReply();
      try {
        const client = getClient();
        const question = interaction.options.getString('question');

        const response = await client.messages.create({
          model: MODEL,
          max_tokens: 1024,
          messages: [{ role: 'user', content: question }],
        });

        const text = response.content.map(block => (block.type === 'text' ? block.text : '')).join('\n').trim();
        await replyWithText(interaction, text || "I didn't get a text response for that.");
      } catch (err) {
        await interaction.editReply(`⚠️ AI request failed: ${err.message}`);
      }
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('chat')
      .setDescription('Have an ongoing conversation with the AI in this channel')
      .addStringOption(o => o.setName('message').setDescription('Your message').setRequired(true)),
    async execute(interaction) {
      await interaction.deferReply();
      try {
        const client = getClient();
        const messageText = interaction.options.getString('message');
        const key = interaction.channel.id;

        const history = conversations.get(key) || [];
        history.push({ role: 'user', content: messageText });

        const response = await client.messages.create({
          model: MODEL,
          max_tokens: 1024,
          messages: history,
        });

        const text = response.content.map(block => (block.type === 'text' ? block.text : '')).join('\n').trim();
        history.push({ role: 'assistant', content: text });

        // Keep history bounded so the context doesn't grow forever.
        while (history.length > MAX_HISTORY_MESSAGES) history.shift();
        conversations.set(key, history);

        await replyWithText(interaction, text || "I didn't get a text response for that.");
      } catch (err) {
        await interaction.editReply(`⚠️ AI request failed: ${err.message}`);
      }
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('resetchat')
      .setDescription('Clear the AI conversation history for this channel'),
    async execute(interaction) {
      conversations.delete(interaction.channel.id);
      await interaction.reply({ content: '🧹 Cleared the AI conversation history for this channel.', ephemeral: true });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('summarize')
      .setDescription('Summarize the recent conversation in this channel')
      .addIntegerOption(o => o.setName('messages').setDescription('How many recent messages to summarize (default 30, max 100)')),
    async execute(interaction) {
      await interaction.deferReply();
      try {
        const client = getClient();
        const limit = Math.min(interaction.options.getInteger('messages') || 30, 100);

        const fetched = await interaction.channel.messages.fetch({ limit });
        const ordered = Array.from(fetched.values()).reverse();
        const transcript = ordered
          .filter(m => m.content && m.content.trim().length > 0)
          .map(m => `${m.author.username}: ${m.content}`)
          .join('\n');

        if (!transcript) {
          return interaction.editReply("There isn't enough text content in recent messages to summarize.");
        }

        const response = await client.messages.create({
          model: MODEL,
          max_tokens: 512,
          messages: [{
            role: 'user',
            content: `Summarize the key points and any decisions from this Discord conversation in a few short bullet points:\n\n${transcript}`,
          }],
        });

        const text = response.content.map(block => (block.type === 'text' ? block.text : '')).join('\n').trim();
        const embed = new EmbedBuilder()
          .setColor(0x9B59B6)
          .setTitle(`📝 Summary of last ${ordered.length} messages`)
          .setDescription(text.slice(0, 4000));
        await interaction.editReply({ embeds: [embed] });
      } catch (err) {
        await interaction.editReply(`⚠️ AI request failed: ${err.message}`);
      }
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('aitranslate')
      .setDescription('Translate text using AI')
      .addStringOption(o => o.setName('text').setDescription('Text to translate').setRequired(true))
      .addStringOption(o => o.setName('language').setDescription('Target language, e.g. Spanish').setRequired(true)),
    async execute(interaction) {
      await interaction.deferReply();
      try {
        const client = getClient();
        const text = interaction.options.getString('text');
        const language = interaction.options.getString('language');

        const response = await client.messages.create({
          model: MODEL,
          max_tokens: 1024,
          messages: [{
            role: 'user',
            content: `Translate the following text into ${language}. Reply with only the translation, nothing else:\n\n${text}`,
          }],
        });

        const translated = response.content.map(block => (block.type === 'text' ? block.text : '')).join('\n').trim();
        await replyWithText(interaction, translated);
      } catch (err) {
        await interaction.editReply(`⚠️ AI request failed: ${err.message}`);
      }
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('brainstorm')
      .setDescription('Generate ideas on a topic')
      .addStringOption(o => o.setName('topic').setDescription('What to brainstorm about').setRequired(true))
      .addIntegerOption(o => o.setName('count').setDescription('Number of ideas (default 5, max 15)')),
    async execute(interaction) {
      await interaction.deferReply();
      try {
        const client = getClient();
        const topic = interaction.options.getString('topic');
        const count = Math.min(interaction.options.getInteger('count') || 5, 15);

        const response = await client.messages.create({
          model: MODEL,
          max_tokens: 1024,
          messages: [{
            role: 'user',
            content: `Brainstorm ${count} distinct, creative ideas about: ${topic}. Format as a numbered list, one line per idea.`,
          }],
        });

        const text = response.content.map(block => (block.type === 'text' ? block.text : '')).join('\n').trim();
        const embed = new EmbedBuilder()
          .setColor(0xF39C12)
          .setTitle(`💡 Brainstorm: ${topic}`)
          .setDescription(text.slice(0, 4000));
        await interaction.editReply({ embeds: [embed] });
      } catch (err) {
        await interaction.editReply(`⚠️ AI request failed: ${err.message}`);
      }
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('explain')
      .setDescription('Get an AI explanation of a topic')
      .addStringOption(o => o.setName('topic').setDescription('What to explain').setRequired(true))
      .addStringOption(o =>
        o.setName('level').setDescription('Explanation level')
          .addChoices(
            { name: 'Like I\'m 5', value: 'a curious 5-year-old' },
            { name: 'Beginner', value: 'a beginner with no background' },
            { name: 'Expert', value: 'someone with expert-level background' },
          )
      ),
    async execute(interaction) {
      await interaction.deferReply();
      try {
        const client = getClient();
        const topic = interaction.options.getString('topic');
        const level = interaction.options.getString('level') || 'a beginner with no background';

        const response = await client.messages.create({
          model: MODEL,
          max_tokens: 1024,
          messages: [{
            role: 'user',
            content: `Explain "${topic}" to ${level}. Keep it concise and clear.`,
          }],
        });

        const text = response.content.map(block => (block.type === 'text' ? block.text : '')).join('\n').trim();
        await replyWithText(interaction, text);
      } catch (err) {
        await interaction.editReply(`⚠️ AI request failed: ${err.message}`);
      }
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('rewrite')
      .setDescription('Rewrite text in a different tone or style')
      .addStringOption(o => o.setName('text').setDescription('Text to rewrite').setRequired(true))
      .addStringOption(o =>
        o.setName('style').setDescription('Target tone/style').setRequired(true)
          .addChoices(
            { name: 'Formal', value: 'formal and professional' },
            { name: 'Casual', value: 'casual and friendly' },
            { name: 'Concise', value: 'as concise as possible' },
            { name: 'Persuasive', value: 'persuasive and compelling' },
            { name: 'Funny', value: 'humorous and lighthearted' },
          )
      ),
    async execute(interaction) {
      await interaction.deferReply();
      try {
        const client = getClient();
        const text = interaction.options.getString('text');
        const style = interaction.options.getString('style');

        const response = await client.messages.create({
          model: MODEL,
          max_tokens: 1024,
          messages: [{
            role: 'user',
            content: `Rewrite the following text to be ${style}. Reply with only the rewritten text:\n\n${text}`,
          }],
        });

        const rewritten = response.content.map(block => (block.type === 'text' ? block.text : '')).join('\n').trim();
        await replyWithText(interaction, rewritten);
      } catch (err) {
        await interaction.editReply(`⚠️ AI request failed: ${err.message}`);
      }
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('codehelp')
      .setDescription('Get AI help with a coding question')
      .addStringOption(o => o.setName('question').setDescription('Your coding question').setRequired(true))
      .addStringOption(o => o.setName('language').setDescription('Programming language, e.g. Python')),
    async execute(interaction) {
      await interaction.deferReply();
      try {
        const client = getClient();
        const question = interaction.options.getString('question');
        const language = interaction.options.getString('language');
        const prompt = language
          ? `Coding question (${language}): ${question}`
          : `Coding question: ${question}`;

        const response = await client.messages.create({
          model: MODEL,
          max_tokens: 1500,
          messages: [{ role: 'user', content: prompt }],
        });

        const text = response.content.map(block => (block.type === 'text' ? block.text : '')).join('\n').trim();
        await replyWithText(interaction, text);
      } catch (err) {
        await interaction.editReply(`⚠️ AI request failed: ${err.message}`);
      }
    },
  },
];
