const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { AudioPlayerStatus } = require('@discordjs/voice');
const musicQueue = require('../music/queue');

function requireVoiceChannel(interaction) {
  const member = interaction.member;
  const voiceChannel = member.voice?.channel;
  if (!voiceChannel) {
    return null;
  }
  return voiceChannel;
}

module.exports = [
  {
    data: new SlashCommandBuilder()
      .setName('play')
      .setDescription('Play a song or add it to the queue')
      .addStringOption(o => o.setName('query').setDescription('Song name or YouTube URL').setRequired(true)),
    async execute(interaction) {
      const voiceChannel = requireVoiceChannel(interaction);
      if (!voiceChannel) {
        return interaction.reply({ content: 'You need to be in a voice channel to use this.', ephemeral: true });
      }
      if (!musicQueue.isPlayAvailable()) {
        return interaction.reply({ content: "⚠️ Music playback isn't set up yet. Run `npm install play-dl @discordjs/voice` first.", ephemeral: true });
      }

      await interaction.deferReply();
      try {
        const query = interaction.options.getString('query');
        const { song, position } = await musicQueue.addSong(
          interaction.guild, voiceChannel, interaction.channel, query, interaction.user.tag
        );

        if (position === 1) {
          await interaction.editReply(`▶️ Now playing: **${song.title}**`);
        } else {
          await interaction.editReply(`➕ Added to queue (position ${position}): **${song.title}**`);
        }
      } catch (err) {
        await interaction.editReply(`⚠️ Couldn't play that: ${err.message}`);
      }
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('pause')
      .setDescription('Pause the current song'),
    async execute(interaction) {
      const queue = musicQueue.getQueue(interaction.guild.id);
      if (!queue || !queue.playing) return interaction.reply({ content: 'Nothing is playing right now.', ephemeral: true });

      queue.player.pause();
      await interaction.reply('⏸️ Paused.');
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('resume')
      .setDescription('Resume the paused song'),
    async execute(interaction) {
      const queue = musicQueue.getQueue(interaction.guild.id);
      if (!queue) return interaction.reply({ content: 'Nothing is queued right now.', ephemeral: true });

      queue.player.unpause();
      await interaction.reply('▶️ Resumed.');
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('skip')
      .setDescription('Skip the current song'),
    async execute(interaction) {
      const queue = musicQueue.getQueue(interaction.guild.id);
      if (!queue || queue.songs.length === 0) return interaction.reply({ content: 'Nothing to skip.', ephemeral: true });

      const skipped = queue.songs[0];
      queue.player.stop(); // triggers Idle handler, which advances the queue
      await interaction.reply(`⏭️ Skipped **${skipped.title}**.`);
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('stop')
      .setDescription('Stop playback and clear the queue'),
    async execute(interaction) {
      const queue = musicQueue.getQueue(interaction.guild.id);
      if (!queue) return interaction.reply({ content: 'Nothing is playing right now.', ephemeral: true });

      queue.songs = [];
      musicQueue.destroyQueue(interaction.guild.id);
      await interaction.reply('⏹️ Stopped playback and cleared the queue.');
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('queue')
      .setDescription('View the current music queue'),
    async execute(interaction) {
      const queue = musicQueue.getQueue(interaction.guild.id);
      if (!queue || queue.songs.length === 0) {
        return interaction.reply('The queue is empty.');
      }

      const lines = queue.songs
        .slice(0, 15)
        .map((s, i) => `${i === 0 ? '▶️' : `${i}.`} **${s.title}** — requested by ${s.requestedBy}`);

      const embed = new EmbedBuilder()
        .setColor(0x1DB954)
        .setTitle('🎵 Music Queue')
        .setDescription(lines.join('\n'))
        .setFooter({ text: `${queue.songs.length} song(s) in queue | Loop: ${queue.loop ? 'song' : queue.loopQueue ? 'queue' : 'off'}` });

      await interaction.reply({ embeds: [embed] });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('nowplaying')
      .setDescription('View the currently playing song'),
    async execute(interaction) {
      const queue = musicQueue.getQueue(interaction.guild.id);
      if (!queue || !queue.songs[0]) return interaction.reply({ content: 'Nothing is playing right now.', ephemeral: true });

      const song = queue.songs[0];
      const embed = new EmbedBuilder()
        .setColor(0x1DB954)
        .setTitle('🎵 Now Playing')
        .setDescription(`**${song.title}**`)
        .addFields({ name: 'Requested by', value: song.requestedBy });

      await interaction.reply({ embeds: [embed] });
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('loop')
      .setDescription('Loop the current song or the whole queue')
      .addStringOption(o =>
        o.setName('mode').setDescription('What to loop').setRequired(true)
          .addChoices(
            { name: 'Off', value: 'off' },
            { name: 'Song', value: 'song' },
            { name: 'Queue', value: 'queue' },
          )
      ),
    async execute(interaction) {
      const queue = musicQueue.getQueue(interaction.guild.id);
      if (!queue) return interaction.reply({ content: 'Nothing is playing right now.', ephemeral: true });

      const mode = interaction.options.getString('mode');
      queue.loop = mode === 'song';
      queue.loopQueue = mode === 'queue';

      await interaction.reply(`🔁 Loop mode set to **${mode}**.`);
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('shuffle')
      .setDescription('Shuffle the music queue'),
    async execute(interaction) {
      const queue = musicQueue.getQueue(interaction.guild.id);
      if (!queue || queue.songs.length < 3) {
        return interaction.reply({ content: 'Not enough songs in the queue to shuffle.', ephemeral: true });
      }

      const current = queue.songs.shift();
      for (let i = queue.songs.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [queue.songs[i], queue.songs[j]] = [queue.songs[j], queue.songs[i]];
      }
      queue.songs.unshift(current);

      await interaction.reply('🔀 Queue shuffled.');
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('remove')
      .setDescription('Remove a song from the queue')
      .addIntegerOption(o => o.setName('position').setDescription('Position in queue (use /queue to check numbers)').setRequired(true)),
    async execute(interaction) {
      const queue = musicQueue.getQueue(interaction.guild.id);
      const position = interaction.options.getInteger('position');

      if (!queue || position < 1 || position >= queue.songs.length) {
        return interaction.reply({ content: 'Invalid queue position.', ephemeral: true });
      }

      const [removed] = queue.songs.splice(position, 1);
      await interaction.reply(`🗑️ Removed **${removed.title}** from the queue.`);
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('volume')
      .setDescription('Adjust playback volume')
      .addIntegerOption(o => o.setName('percent').setDescription('Volume percent (0-200)').setRequired(true)),
    async execute(interaction) {
      const queue = musicQueue.getQueue(interaction.guild.id);
      if (!queue) return interaction.reply({ content: 'Nothing is playing right now.', ephemeral: true });

      const percent = interaction.options.getInteger('percent');
      if (percent < 0 || percent > 200) {
        return interaction.reply({ content: 'Choose a value between 0 and 200.', ephemeral: true });
      }

      queue.volume = percent / 100;
      queue.currentResource?.volume?.setVolume(queue.volume);
      await interaction.reply(`🔊 Volume set to ${percent}%.`);
    },
  },

  {
    data: new SlashCommandBuilder()
      .setName('leavevc')
      .setDescription('Make the bot leave the voice channel'),
    async execute(interaction) {
      const queue = musicQueue.getQueue(interaction.guild.id);
      if (!queue) return interaction.reply({ content: "I'm not in a voice channel.", ephemeral: true });

      musicQueue.destroyQueue(interaction.guild.id);
      await interaction.reply('👋 Left the voice channel.');
    },
  },
];
